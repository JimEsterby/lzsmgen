This directory intended for automated reports.

Right now, only the coverage html report is generated here.
